import pygame
import numpy as np
import random




class You(pygame.sprite.Sprite):
    def __init__(self, filename):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(filename).convert_alpha()
        self.rect = self.image.get_rect(topleft=(560, 560))

        pygame.sprite.Sprite.__init__(self)
        self.image_fly = pygame.image.load('fly_thing.png').convert_alpha()
        self.rect_fly = self.image.get_rect(topleft=(560, 560))


    def move(self, rect_name):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_d] and self.rect.right < 1200:
            rect_name.move_ip(3, 0)
        elif keys[pygame.K_a] and self.rect.left > 0:
            rect_name.move_ip(-3, 0)

    def line_exist(self,  sc):
        mousepos = pygame.mouse.get_pos()
        pygame.draw.aaline(sc, (255,0,0), (self.rect.topleft[0] + 15, self.rect.topleft[1]) , mousepos)
        pygame.draw.aaline(sc, (255, 0, 0), (self.rect.topright[0] - 15, self.rect.topright[1]), mousepos)
        pygame.display.flip()


    def point(self, sc):
        mousepos = pygame.mouse.get_pos()
        image_bullet = pygame.image.load('sniper_bullet.png')
        self.rect_bullet = image_bullet.get_rect(center=(mousepos))
        sc.blit(image_bullet, self.rect_bullet)

    def health_check(self, sc, health):
        health -=10
        f_sans = pygame.font.SysFont('comicsansms', 24)
        health_str = str(health)
        sc_text = f_sans.render(('Your health:'+ health_str), True, (0,0,255), (0,0,0))
        pos = sc_text.get_rect(center=(600, 650))

        sc.blit(sc_text, pos)


def act(c):
        return 0 if c < 0.3 else 1

class AI():
    def __init__(self):
        self.image_ai = pygame.image.load("ai.png")
        self.rect_ai = self.image_ai.get_rect(topleft=(random.randint(0,1100), random.randint(10,540)))

    def move_by_player(self, sc):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and self.rect_ai.left > 0:
            self.rect_ai.move_ip(-4, 0)
        elif keys[pygame.K_RIGHT] and self.rect_ai.right < 1200:
            self.rect_ai.move_ip(4, 0)
        elif keys[pygame.K_UP] and self.rect_ai.top > 0:
            self.rect_ai.move_ip(0, -4)
        elif keys[pygame.K_DOWN] and self.rect_ai.top < 550:
            self.rect_ai.move_ip(0, 4)


    def exist(self,sc):
        sc.blit(self.image_ai, self.rect_ai)

    def direction_change(self):
        s = random.randint(0,10)
        direct = [s, -s]
        x = random.choice(direct)
        return x

    def move(self, x, y):
        self.rect_ai.move_ip(x, y)


    def NN_beh(self, point_rect, w11_num):

        range = 100 / ((self.rect_ai.centerx - point_rect.centerx)**2 + (self.rect_ai.centery - point_rect.centery)**2)**0.5
        if range == 0:
            range += 1
        round_range = round(range, 2)

        c = np.array([round_range])
        w11 = [w11_num]
        w22 = [0]
        weight1 = np.array([w11, w22])
        weight2 = np.array([1, 1])

        sum_hidden = np.dot(weight1, c)


        out_hidden = np.array([act(c) for c in sum_hidden])


        sum_end = np.dot(weight2, out_hidden)
        v = act(sum_end)


        return v

    def reapper(self):
        self.rect_ai = self.image_ai.get_rect(topleft=(random.randint(0, 1100), random.randint(10, 540)))














        #def death(self, c):
        #self.image_fly = pygame.transform.rotate(self.image_fly, c)


        #Создать линию от курора до центра игрока и top игрока, затем при отклонении вращать рект, пока линия не будет
        #пересекать их снова











