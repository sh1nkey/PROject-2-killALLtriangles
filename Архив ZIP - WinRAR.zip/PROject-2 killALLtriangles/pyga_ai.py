import pygame
from pyga_ai_support import You
from pyga_ai_support import AI
import random

width, height = 1200, 720

pygame.init()
sc = pygame.display.set_mode((width,height))
pygame.display.set_caption("killALLtriangles")
pygame.display.set_icon(pygame.image.load("LOGO.bmp"))
clock = pygame.time.Clock()

FPS = 60
blue = (0,0,255)
red = (255,0,0)
white = (255,255,255)
black = (0,0,0)
health_y = 110
you = You('test_sprite.png')
ai = AI()
pygame.mouse.set_visible(False)
background_image = pygame.image.load("space.png")


ai1 = AI()
ai2 = AI()
ai3 = AI()
ai4 = AI()
ai5 = AI()
ai6 = AI()
running = True

w11 =round(random.random(), 2)
w22 =round(random.random(), 2)
w33 =round(random.random(), 2)
w44 =round(random.random(), 2)
w55 =round(random.random(), 2)
w66 =round(random.random(), 2)
b_e_1 = 0
b_e_2 = 0
b_e_3 = 0
b_e_4 = 0
b_e_5 = 0
b_e_6 = 0

dead = []
while running:
    if health_y <= 0:
        running = False
    sc.blit(background_image, (0,0))
    keys = pygame.key.get_pressed()
    if b_e_1 == 0:
        ai1.exist(sc)
    if b_e_2 == 0:
        ai2.exist(sc)
    if b_e_3 == 0:
        ai3.exist(sc)
    if b_e_4 == 0:
        ai4.exist(sc)
    if b_e_5 == 0:
        ai5.exist(sc)
    if b_e_6 == 0:
        ai6.exist(sc)

    if b_e_1 == 1:
        ai1.rect_ai = ai1.image_ai.get_rect(topleft=(1300, 1200))
    if b_e_2 == 1:
        ai2.rect_ai = ai2.image_ai.get_rect(topleft=(1300, 1200))
    if b_e_3 == 1:
        ai3.rect_ai = ai3.image_ai.get_rect(topleft=(1300, 1200))
    if b_e_4 == 1:
        ai4.rect_ai = ai4.image_ai.get_rect(topleft=(1300, 1200))
    if b_e_5 == 1:
        ai5.rect_ai = ai5.image_ai.get_rect(topleft=(1300, 1200))
    if b_e_6 == 1:
        ai6.rect_ai = ai6.image_ai.get_rect(topleft=(1300, 1200))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
                you.line_exist(sc)
                you.line_exist(sc)
                you.line_exist(sc)
                you.line_exist(sc)
                you.line_exist(sc)
                you.line_exist(sc)
                you.line_exist(sc)
                if not you.rect_bullet.colliderect(ai1.rect_ai) and not you.rect_bullet.colliderect(ai2.rect_ai)\
                        and not you.rect_bullet.colliderect(ai3.rect_ai) and not you.rect_bullet.colliderect(ai4.rect_ai)\
                        and not you.rect_bullet.colliderect(ai5.rect_ai) and not you.rect_bullet.colliderect(ai6.rect_ai):
                    health_y -= 5


                elif you.rect_bullet.colliderect(ai1.rect_ai):
                    health_y += 10
                    b_e_1 = 1
                    dead.append(w11)
                elif you.rect_bullet.colliderect(ai2.rect_ai):
                    health_y += 10
                    b_e_2 = 1
                    dead.append(w22)
                elif you.rect_bullet.colliderect(ai3.rect_ai):
                    health_y += 10
                    b_e_3 = 1
                    dead.append(w33)
                elif you.rect_bullet.colliderect(ai4.rect_ai):
                    health_y += 10
                    b_e_4 = 1
                    dead.append(w44)
                elif you.rect_bullet.colliderect(ai5.rect_ai):
                    health_y += 10
                    b_e_5 = 1
                    dead.append(w55)
                elif you.rect_bullet.colliderect(ai6.rect_ai):
                    health_y += 10
                    b_e_6 = 1
                    dead.append(w66)


    you.point(sc)
    if ai1.NN_beh(you.rect_bullet, w11) == 1:
        if ai1.rect_ai.left > 0 and ai1.rect_ai.right < 1200 and ai1.rect_ai.bottom < 720 and ai1.rect_ai.top > 0:
            ai1.move(ai.direction_change(), ai.direction_change())


    if ai2.NN_beh(you.rect_bullet, w22) == 1:
        if ai2.rect_ai.left > 0 and ai2.rect_ai.right < 1200 and ai2.rect_ai.bottom < 720 and ai2.rect_ai.top > 0:
            ai2.move(ai.direction_change(), ai.direction_change())


    if ai3.NN_beh(you.rect_bullet, w33) == 1:
        if ai3.rect_ai.left > 0 and ai3.rect_ai.right < 1200 and ai3.rect_ai.bottom < 720 and ai3.rect_ai.top > 0:
            ai3.move(ai.direction_change(), ai.direction_change())


    if ai4.NN_beh(you.rect_bullet, w44) == 1:
        if ai4.rect_ai.left > 0 and ai4.rect_ai.right < 1200 and ai4.rect_ai.bottom < 720 and ai1.rect_ai.top > 0:
            ai4.move(ai.direction_change(), ai.direction_change())


    if ai5.NN_beh(you.rect_bullet, w55) == 1:
        if ai5.rect_ai.left > 0 and ai4.rect_ai.right < 1200 and ai4.rect_ai.bottom < 720 and ai1.rect_ai.top > 0:
            ai5.move(ai.direction_change(), ai.direction_change())


    if ai6.NN_beh(you.rect_bullet, w66) == 1:
        if ai6.rect_ai.left > 0 and ai4.rect_ai.right < 1200 and ai4.rect_ai.bottom < 720 and ai1.rect_ai.top > 0:
            ai6.move(ai.direction_change(), ai.direction_change())



    you.move(you.rect)
    you.move(you.rect_fly)
    you.point(sc)
    you.health_check(sc, health_y)
    print(dead)
    if len(dead) >= 6 or keys[pygame.K_r]:
        w11 = random.normalvariate(dead[-1], 0.6)
        w22 = random.normalvariate(dead[-1], 0.6)
        w33 = random.normalvariate(dead[-1], 0.6)
        w44 = random.normalvariate(dead[-1], 0.6)
        w55 = random.normalvariate(dead[-1], 0.6)
        w66 = random.normalvariate(dead[-1], 0.6)

        b_e_1 = 0
        b_e_2 = 0
        b_e_3 = 0
        b_e_4 = 0
        b_e_5 = 0
        b_e_6 = 0

        ai1.reapper()
        ai2.reapper()
        ai3.reapper()
        ai4.reapper()
        ai5.reapper()
        ai6.reapper()

        dead.clear()

    sc.blit(you.image, you.rect)
    sc.blit(you.image_fly, you.rect_fly)

    pygame.display.update()
    pygame.time.Clock()